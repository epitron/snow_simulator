#!/bin/bash
OPTS="-O3 -ffast-math -fexpensive-optimizations -fomit-frame-pointer"
rm *.o
g++ $OPTS -c HeightFieldGenerator.cpp
g++ $OPTS -c -Wno-deprecated Snow.cpp
g++ $OPTS -c -Wno-deprecated flake.cpp
g++ $OPTS -c -Wno-deprecated vector.cpp
g++ $OPTS -c -Wno-deprecated main.cpp
gcc $OPTS -c glm.c
g++ -o snow HeightFieldGenerator.o Snow.o flake.o glm.o vector.o main.o -lGL -lGLU -lglut
